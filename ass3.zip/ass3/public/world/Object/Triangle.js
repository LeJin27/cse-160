class Triangle {
  constructor( ) {
    this.type = 'triangle';
    this.position = [0.0, 0.0, 0.0];
    this.color = [1.0, 1.0, 1.0, 1.0];
    this.size = 5.0;
  }

  render () {
    var xy = this.position;
    var rgba = this.color;

    gl.uniform4f(u_FragColor, rgba[0], rgba[1], rgba[2], rgba[3]);
    const delta = this.size / 200.0;
    drawTriangle([xy[0], xy[1], xy[0] + delta, xy[1], xy[0], xy[1] + delta]);
  }

}


function drawTriangle(vertices) {
  const n = 3; // The number of vertices

  // Bind the buffer object to target
  gl.bindBuffer(gl.ARRAY_BUFFER, g_buffer);

  // Write date into the buffer object
  const float32Vertices = new Float32Array(vertices)
  gl.bufferData(gl.ARRAY_BUFFER, float32Vertices, gl.DYNAMIC_DRAW);

  if (a_Position < 0) {
    console.log('Failed to get the storage location of a_Position');
    return -1;
  }
  // Assign the buffer object to a_Position variable
  gl.vertexAttribPointer(a_Position, 2, gl.FLOAT, false, 0, 0);
  // Enable the assignment to a_Position variable
  gl.enableVertexAttribArray(a_Position);

  gl.drawArrays(gl.TRIANGLES, 0, n);
}
function drawTriangle3D(vertices) {
  const verticeCount = 3; 

  //const offsetVertices = vertices.map((value) => value - 0.5)

  const helperTriangleCreateSurface = () => {
    gl.bindBuffer(gl.ARRAY_BUFFER, g_buffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.DYNAMIC_DRAW);

    gl.vertexAttribPointer(a_Position, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(a_Position);
  }


  helperTriangleCreateSurface();

  gl.drawArrays(gl.TRIANGLES, 0, verticeCount);
}


function drawTriangle3DUV(vertices, uv) {
  const verticeCount = 3; 

  const offsetVertices = vertices.map((value) => value - 0.5)

  const helperTriangleCreateSurface = () => {
    gl.bindBuffer(gl.ARRAY_BUFFER, g_buffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(offsetVertices), gl.DYNAMIC_DRAW);

    gl.vertexAttribPointer(a_Position, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(a_Position);
  }

  const helperTriangleCreateTexture = () => {
    gl.bindBuffer(gl.ARRAY_BUFFER, g_uvBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(uv), gl.DYNAMIC_DRAW);

    gl.vertexAttribPointer(a_UV, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(a_UV);
  }

  helperTriangleCreateSurface();
  helperTriangleCreateTexture();

  gl.drawArrays(gl.TRIANGLES, 0, verticeCount);
}